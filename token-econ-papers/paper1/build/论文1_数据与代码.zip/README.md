# 复现说明

## 运行顺序
1. `python3 data_gen.py` —— 生成 data/results.json 与面板 CSV（固定随机种子，可复现）
2. `python3 figures.py`  —— 生成 figs/ 下全部图件
3. `python3 assemble.py` —— 装配 Word 论文到 build/

## 依赖
numpy、pandas、scipy、python-docx、matplotlib；公式转换需 pandoc。

## 数据说明
分析样本为按 data/facts.md 记录的公开口径**校准生成的模拟面板**，
用于完整展示测度与识别链条，非真实抽样采集；该点已在正文数据小节与脚注中声明。
公开事实锚见 data/facts.md（逐条附发布主体与来源链接），
实证结果速查见 data/RESULTS_SPEC.md。

## 文件
- data_gen.py：数据生成与全部估计
- figures.py：图件
- content_a/b/c.py：正文分部分
- refs_pool.py：参考文献池（逐条联网核实）
- DESIGN.md：选题设计与口径更正留档
